/* unixodbc.h.  Generated from unixodbc.h.in by configure.  */
/* Preprocessor constants for unixODBC */

/* Define to 1 if `long long' is available */
#define HAVE_LONG_LONG 1

/* Define to 1 if the <pwd.h> header file is present */
#define HAVE_PWD_H 1

/* Define to 1 if the <sys/types.h> header file is present */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if the <unistd.h> header file is present */
#define HAVE_UNISTD_H 1

/* Define to the value of sizeof(long) */
#define SIZEOF_LONG_INT 8
